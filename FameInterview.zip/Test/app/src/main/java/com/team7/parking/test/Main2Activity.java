package com.team7.parking.test;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.team7.parking.test.data.Channel;
import com.team7.parking.test.service.YahooWeatherServices;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Locale;

public class Main2Activity extends AppCompatActivity implements LocationListener {
    //https://androstock.com/tutorials/getting-current-location-latitude-longitude-country-android-android-studio.html
    //EditText name, email_address, phone, description;
    LocationManager locationManager;
    Button submit, get_loc, btn2;
    TextView display, display_loc;
    String total="";

    TextView tv1;
    String temp1, temp2, temp3, temp4;
    double latitude ;
    double longitude;
    String value;
    DatabaseReference database = FirebaseDatabase.getInstance().getReference("People");
    private YahooWeatherServices yahooWeatherServices;


    String weatherWebserviceURL = "http://api.openweathermap.org/data/2.5/weather?q=ariana,tn&appid=6cf1c2a4c826ea492d83d0fcd915f50c&units=metric";
    //the loading Dialog
    ProgressDialog pDialog;
    // Textview to show temperature and description
    TextView temperature, description;
    // background image
    ImageView weatherBackground;
    // JSON object that contains weather information
    JSONObject jsonObj;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Show Weather");

        tv1= (TextView) findViewById(R.id.tv1);
        btn2 = (Button) findViewById(R.id.btn2);



        //value = getIntent().getExtras().getString("Money");

        JsonObjectRequest jsonObjReq = new JsonObjectRequest(Request.Method.GET,
                weatherWebserviceURL, null, new Response.Listener<JSONObject>() {

            @Override
            public void onResponse(JSONObject response) {
                try {
                    // Parsing json object response
                    // response will be a json object


                    jsonObj = (JSONObject) response.getJSONArray("weather").get(0);
                    // display weather description into the "description textview"
                    tv1.setText(jsonObj.getString("description"));
                    // display the temperature
                    tv1.append(response.getJSONObject("main").getString("temp") + " °C");

                    String backgroundImage = "";


                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(getApplicationContext(), "Error , try again ! ", Toast.LENGTH_LONG).show();
                    pDialog.dismiss();

                }


            }


        }, new Response.ErrorListener() {

            @Override
            public void onErrorResponse(VolleyError error) {
                VolleyLog.d("tag", "Error: " + error.getMessage());
                Toast.makeText(getApplicationContext(), "Error while loading ... ", Toast.LENGTH_SHORT).show();
                // hide the progress dialog
                pDialog.dismiss();
            }
        });

        // Adding request to request queue
        AppController.getInstance(this).addToRequestQueue(jsonObjReq);



        btn2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                //total = "";
                //total+="Name : "+name.getText().toString()+"\nEmail address : "+email_address.getText().toString();
                //total+="\nPhone Number : "+phone.getText().toString()+"\nDescription : "+description.getText().toString();
                //display.setText(total);
                getLocation();
                /***/


            }
        });

        if (ContextCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getApplicationContext(), android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION, android.Manifest.permission.ACCESS_COARSE_LOCATION}, 101);

        }
    }
    void getLocation() {
        try {
            locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 5000, 5, this);
        }
        catch(SecurityException e) {
            e.printStackTrace();
        }
    }
    @Override
    public void onLocationChanged(Location location) {
        latitude = location.getLatitude();
        longitude = location.getLongitude();
        tv1.setText("Latitude: " + location.getLatitude() + "\n Longitude: " + location.getLongitude());

        try {

            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            tv1.setText("\n"+addresses.get(0).getAddressLine(0)+", "+
                    addresses.get(0).getAddressLine(1)+", "+addresses.get(0).getAddressLine(2));
            String temp = tv1.getText().toString();
            temp = temp.replaceAll(", null","");
            tv1.setText(temp);
            //Toast.makeText(Main2Activity.this,"there", Toast.LENGTH_SHORT).show();

            //}

        }catch(Exception e)
        {

        }


        //long sec=3000;
        //wait(sec);


//        Intent intent1 = new Intent(Main2Activity.this, Main5Activity.class);
//        String t = Double.toString(latitude)+"\n"+Double.toString(longitude);
//        intent1.putExtra("Point",t);
//
//        startActivity(intent1);
//
//        Intent intent11 = new Intent(Main2Activity.this, Main6Activity.class);
//        intent11.putExtra("Money",value);
//        startActivity(intent11);

    }

    @Override
    public void onProviderDisabled(String provider) {
        Toast.makeText(Main2Activity.this, "Please Enable GPS and Internet", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }




}
