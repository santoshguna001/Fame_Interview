package com.team7.parking.test.service;
import android.os.AsyncTask;

public class YahooWeatherServices {

    private WeatherServiceCallBack callBack;
    private String location;

    public YahooWeatherServices(WeatherServiceCallBack callBack){
        this.callBack = callBack;
    }

    public String getLocation(){
        return location;
    }

    public void refreshWeather(String location){

        new AsyncTask<String, Void, String>(){
            @Override
            protected String doInBackground(String... strings){
                return null;
            }

            @Override
            protected void onPostExecute(String s){
                super.onPostExecute(s);
            }
        }.execute(location);
    }
}
