package com.team7.parking.test.data;
import org.json.JSONObject;

public interface JSONPopulator {
    void populate(JSONObject data);
}
