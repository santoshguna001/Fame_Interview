package com.team7.parking.test.data;

public class Channel {
}
