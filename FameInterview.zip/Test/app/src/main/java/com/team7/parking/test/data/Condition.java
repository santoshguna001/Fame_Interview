package com.team7.parking.test.data;

import org.json.JSONObject;

public class Condition implements JSONPopulator {
    @Override
    public void populate(JSONObject data){

    }
}
