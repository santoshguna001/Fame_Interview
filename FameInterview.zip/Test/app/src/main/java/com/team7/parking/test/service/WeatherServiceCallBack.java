package com.team7.parking.test.service;
import com.team7.parking.test.data.Channel;

public interface WeatherServiceCallBack {
    void serviceSuccess(Channel channel);
    void serviceFailure(Exception exception);
}
